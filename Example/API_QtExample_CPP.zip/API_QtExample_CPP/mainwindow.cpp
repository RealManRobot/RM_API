﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_pApi = new RM_Service();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 休眠(毫秒)
void sleep_cp(int milliseconds)
{
#ifdef _WIN32
    Sleep(milliseconds);
#endif

#ifdef __linux
    usleep(milliseconds * 1000);
#endif
}

// 透传接口回调函数
void MCallback(CallbackData data)
{
    qDebug() << "MCallback MCallback MCallback";
    // 判断接口类型
    switch(data.codeKey)
    {
        case MOVEJ_CANFD_CB: // 角度透传
            qDebug() << u8"透传结果:" << data.errCode;
            qDebug() << u8"当前角度:" << data.joint[0] << data.joint[1] << data.joint[2] << data.joint[3] << data.joint[4] << data.joint[5];
        break;
        case MOVEP_CANFD_CB: // 位姿透传
            qDebug() << u8"透传结果:" << data.errCode;
            qDebug() << u8"当前角度:" << data.joint[0] << data.joint[1] << data.joint[2] << data.joint[3] << data.joint[4] << data.joint[5];
            qDebug() << u8"当前位姿:" << data.pose.position.x << data.pose.position.y << data.pose.position.z << data.pose.euler.rx << data.pose.euler.ry << data.pose.euler.rz;
        break;
        case FORCE_POSITION_MOVE_CB: // 力位混合透传
            qDebug() << u8"透传结果:" << data.errCode << data.nforce << data.sys_err;
            qDebug() << u8"当前角度:" << data.joint[0] << data.joint[1] << data.joint[2] << data.joint[3] << data.joint[4] << data.joint[5];
            qDebug()<<u8"系统外部力"<< data.direction_force[0]<< data.direction_force[1] << data.direction_force[2] << data.direction_force[3] << data.direction_force[4] << data.direction_force[5];
        break;
    }

}

// 开始连接
void MainWindow::on_pushButton_Start_clicked()
{
    // 初始化API, 注册回调函数
    m_pApi->Service_RM_API_Init(65, MCallback);

    // 连接服务器
    m_sockhand =  Arm_Socket_Start((char*)"192.168.1.18", 8080, 5000);
    qDebug() << "m_sockhand:" << m_sockhand;

    char* version;
    version = m_pApi->Service_API_Version();
    qDebug() << "version:" << version;
}

// 常用接口使用示例
void MainWindow::on_pushButton_Test_clicked()
{
    int ret = -1;
    // 网络连接状态
    ret = m_pApi->Service_Arm_Socket_State(m_sockhand);
    ui->textEdit->append(QString(u8"网络连接状态 Arm_Socket_State: [%1]").arg(ret));

    //清除关节错误代码
    ret = m_pApi->Service_Set_Joint_Err_Clear( m_sockhand, 1, RM_BLOCK);
    ui->textEdit->append(QString(u8"清除关节错误代码 Set_Joint_Err_Clear: [%1]").arg(ret));

    //获取关节最大速度
    float fSpeeds[6] = {0,1,2,3,4,5};
    ret = m_pApi->Service_Get_Joint_Speed(m_sockhand,fSpeeds);
    ui->textEdit->append(QString(u8"获取关节最大速度 Get_Joint_Speed: [%1] - Speed[%2, %3, %4, %5, %6, %7]")
                         .arg(ret).arg(fSpeeds[0]).arg(fSpeeds[1]).arg(fSpeeds[2]).arg(fSpeeds[3]).arg(fSpeeds[4]).arg(fSpeeds[5]));

    //获取关节最大加速度
    float fAccs[6] = {0,1,2,3,4,5};
    ret = m_pApi->Service_Get_Joint_Acc(m_sockhand,fAccs);
    ui->textEdit->append(QString(u8"获取关节最大加速度 Get_Joint_Acc: [%1] - Acc[%2, %3, %4, %5, %6, %7]")
                         .arg(ret).arg(fAccs[0]).arg(fAccs[1]).arg(fAccs[2]).arg(fAccs[3]).arg(fAccs[4]).arg(fAccs[5]) );

    //获取关节最小限位
    float fMinJoint[7] = {0,1,2,3,4,5,6};
    ret = m_pApi->Service_Get_Joint_Min_Pos(m_sockhand,fMinJoint);
    ui->textEdit->append(QString(u8"获取关节最小限位 Get_Joint_Min_Pos: [%1] - MinJoint[%2, %3, %4, %5, %6, %7]")
                         .arg(ret).arg(fMinJoint[0]).arg(fMinJoint[1]).arg(fMinJoint[2]).arg(fMinJoint[3]).arg(fMinJoint[4]).arg(fMinJoint[5]));

    //获取关节最大限位
    float fMaxJoint[7] = {0,1,2,3,4,5,6};
    ret = m_pApi->Service_Get_Joint_Max_Pos(m_sockhand,fMaxJoint);
    ui->textEdit->append(QString(u8"获取关节最大限位 Get_Joint_Max_Pos: [%1] - MaxJoint[%2, %3, %4, %5, %6, %7]")
                         .arg(ret).arg(fMaxJoint[0]).arg(fMaxJoint[1]).arg(fMaxJoint[2]).arg(fMaxJoint[3]).arg(fMaxJoint[4]).arg(fMaxJoint[5]));

    //获取机械臂末端最大线速度
    float fLSpeed = 0;
    ret = m_pApi->Service_Get_Arm_Line_Speed(m_sockhand,&fLSpeed);
    ui->textEdit->append(QString(u8"获取机械臂末端最大线速度 Get_Arm_Line_Speed: [%1] - LineSpeed:[%2]").arg(ret).arg(fLSpeed));

    //获取机械臂末端最大线加速度
    float fLAcc = 0;
    ret = m_pApi->Service_Get_Arm_Line_Acc(m_sockhand,&fLAcc);
     ui->textEdit->append(QString(u8"获取机械臂末端最大线加速度 Get_Arm_Line_Acc: [%1] - fLAcc：[%2]").arg(ret).arg(fLAcc));
}

// 关闭连接
void MainWindow::on_pushButton_Close_clicked()
{
    m_pApi->Service_Arm_Socket_Close(m_sockhand);
    m_sockhand = -1;
}

// // 画8字运动例程
void MainWindow::on_pushButton_move_clicked()
{
    // 回零位
    float joint[6] = {0,0,0,0,0,0};
    int ret = m_pApi->Service_Movej_Cmd(m_sockhand,joint,20,0,0,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("Movej_Cmd 1:[%1]").arg(ret));
        return;
    }
    // 移动到初始点位
    float joint1[6] = {18.44,-10.677,-124.158,-15,-45.131,-71.445};
    ret = m_pApi->Service_Movej_Cmd(m_sockhand,joint1,20,0,0,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("Movej_Cmd 2:[%1]").arg(ret));
        return;
    }

    // 画八字
    for(int i=0;i<3;i++)
    {
        Pose po1,po2,po3;
        po1.position.x = 0.186350; po1.position.y = 0.062099; po1.position.z = 0.2; po1.euler.rx = 3.141; po1.euler.ry = 0; po1.euler.rz = 1.569;
        po2.position.x = 0.21674; po2.position.y = 0.0925; po2.position.z = 0.2; po2.euler.rx = 3.141; po2.euler.ry = 0; po2.euler.rz = 1.569;
        po3.position.x = 0.20785; po3.position.y = 0.114; po3.position.z = 0.2; po3.euler.rx = 3.141; po3.euler.ry = 0; po3.euler.rz = 1.569;
        ret = m_pApi->Service_Movel_Cmd(m_sockhand, po1, 20, 0,0, 1);
        if(ret != 0)
        {
            ui->textEdit->append(QString("Movel_Cmd 1:[%1]").arg(ret));
            return;
        }

        ret = m_pApi->Service_Movec_Cmd(m_sockhand,po2,po3,20,0,0,0,1);
        if(ret != 0)
        {
            ui->textEdit->append(QString("Movec_Cmd 1:[%1]").arg(ret));
            return;
        }

        Pose po4 ,po5,po6;
        po4.position.x = 0.164850;po4.position.y = 0.157;po4.position.z = 0.2;po4.euler.rx = 3.141; po4.euler.ry = 0;po4.euler.rz = 1.569;
        po5.position.x = 0.186350;po5.position.y = 0.208889;po5.position.z = 0.2; po5.euler.rx = 3.141;po5.euler.ry = 0; po5.euler.rz = 1.569;
        po6.position.x = 0.20785;po6.position.y = 0.157;po6.position.z = 0.2; po6.euler.rx = 3.141;po6.euler.ry = 0; po6.euler.rz = 1.569;
        ret = m_pApi->Service_Movel_Cmd(m_sockhand,po4,20,0,0,1);
        if(ret != 0)
        {
            ui->textEdit->append(QString("Movel_Cmd 2:[%1]").arg(ret));
            return;
        }

        ret = m_pApi->Service_Movec_Cmd(m_sockhand,po5,po6,20,0,0,0,1);
        if(ret != 0)
        {
            ui->textEdit->append(QString("Movec_Cmd 2:[%1]").arg(ret));
            return;
        }
    }
    ui->textEdit->append(QString("cycle draw 8 deno:[%1]").arg(ret));
}

void MainWindow::on_pushButton_gripper_clicked()
{
    float joint2[6]={0,0,0,0,0,0};
    float joint3[6]= {4.526,93.549,84,-8.894,-85.343,57.208};
    float joint4[6]= {4.61,93.551,75.276,-10.098,-76.508,57.224};
    float joint5[6]= {4.61,67.175,96.152,-10.385,-71.095,58.244};
    float joint6[6]= {-106.244,67.172,96.15,-10.385,-71.097,58.243};
    m_pApi->Service_Movej_Cmd(m_sockhand,joint2,20,0,0,1);
    int ret = m_pApi->Service_Movej_Cmd(m_sockhand,joint3,20,0,0,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("gripper pick fault1:[%1]").arg(ret));
        return;
    }
    // 设置末端电源输出12V
    m_pApi->Service_Set_Tool_Voltage(m_sockhand,2,1);
    m_pApi->Service_Set_Gripper_Release(m_sockhand,500,1,1);
    sleep_cp(200);
    m_pApi->Service_Movej_Cmd(m_sockhand,joint4,20,0,0,1);
    ret = m_pApi->Service_Set_Gripper_Pick_On(m_sockhand,500,500,1,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("gripper pick fault2:[%1]").arg(ret));
        return;
    }
    sleep_cp(200);
    m_pApi->Service_Movej_Cmd(m_sockhand,joint5,20,0,0,1);
    ret = Movej_Cmd(m_sockhand,joint6,20,0,0,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("gripper pick fault3:[%1]").arg(ret));
        return;
    }
    ret = m_pApi->Service_Set_Gripper_Release(m_sockhand,500,1,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("gripper pick fault4:[%1]").arg(ret));
        return;
    }
    sleep_cp(200);
    ret = m_pApi->Service_Movej_Cmd(m_sockhand,joint5,20,0,0,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("gripper pick fault5:[%1]").arg(ret));
        return;
    }
    ui->textEdit->append(QString("gripper pick success:[%1]").arg(ret));
}

// 关节示教
void MainWindow::on_pushButton_Teach_clicked()
{
    // 回零位
    float joint[6] = {0,0,0,0,0,0};
    int ret = m_pApi->Service_Movej_Cmd(m_sockhand,joint,20,0,0,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("Movej_Cmd 1:[%1]").arg(ret));
        return;
    }
    // 示教
    byte num = 5; byte direction = 1; byte v = 20;
    ret = m_pApi->Service_Joint_Teach_Cmd(m_sockhand,num ,direction ,v,1);
    sleep_cp(2000);
    ret = m_pApi->Service_Teach_Stop_Cmd(m_sockhand,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString(u8"关节示教 fault:[%1]").arg(ret));
        return;
    }
}


void MainWindow::on_pushButton_state_clicked()
{
    // 获取工具坐标系
    FRAME tool;
    int ret = m_pApi->Service_Get_Current_Tool_Frame(m_sockhand,&tool);
    if(ret != 0)
    {
        ui->textEdit->append(QString("Get_Current_Tool_Frame fault:[%1]").arg(ret));
        return;
    }
    ui->textEdit->append(QString(u8"工具坐标系名称:[%1]; ").arg(tool.frame_name.name) +
                         QString(u8"工具姿态:[%1,%2,%3,%4,%5,%6]; ").arg(tool.pose.position.x).arg(tool.pose.position.y).
                         arg(tool.pose.position.z).arg(tool.pose.euler.rx).arg(tool.pose.euler.ry).arg(tool.pose.euler.rz)+
                         QString(u8"重量:[%1]; ").arg(tool.payload)+ QString(u8"质心:[%1,%2,%3]; ").arg(tool.x).arg(tool.y).arg(tool.z));

    // 角度角度运动
    float fl[6] = {0,0,0,0,90,0};
    ret = m_pApi->Service_Movej_Cmd(m_sockhand,fl,20,0,0,1);

    // 获取机械臂当前状态
    float joint[6] ; Pose po1; uint16_t Arm_Err; uint16_t Sys_Err;
    ret = m_pApi->Service_Get_Current_Arm_State(m_sockhand,joint,&po1,&Arm_Err,&Sys_Err);
    if(ret != 0)
    {
        ui->textEdit->append(QString("Get_Current_Arm_State fault:[%1]").arg(ret));
        return;
    }
    ui->textEdit->append(QString(u8"关节角度:[%1,%2,%3,%4,%5,%6]; ").arg(joint[0]).arg(joint[1]).arg(joint[2]).arg(joint[3]).arg(joint[4]).arg(joint[5]) +
                         QString(u8"末端位姿:[%1,%2,%3,%4,%5,%6]; ").arg(po1.position.x).arg(po1.position.y).arg(po1.position.z).arg(po1.euler.rx).arg(po1.euler.ry).arg(po1.euler.rz)+
                         QString(u8"机械臂运行错误代码:[%1]; ").arg(Arm_Err)+ QString(u8"控制器错误代码:[%1]; ").arg(Sys_Err));

    // 关节姿态运动
    ret = m_pApi->Service_Movej_P_Cmd(m_sockhand,po1,20,0,0,1);
    ret = m_pApi->Service_Get_Current_Arm_State(m_sockhand,joint,&po1,&Arm_Err,&Sys_Err);
    if(ret != 0)
    {
        ui->textEdit->append(QString("获取机械臂状态 Get_Current_Arm_State :[%1]").arg(ret));
        return;
    }
    ui->textEdit->append(QString(u8"关节角度:[%1,%2,%3,%4,%5,%6]; ").arg(joint[0]).arg(joint[1]).arg(joint[2]).arg(joint[3]).arg(joint[4]).arg(joint[5]) +
                         QString(u8"末端位姿:[%1,%2,%3,%4,%5,%6]; ").arg(po1.position.x).arg(po1.position.y).arg(po1.position.z).arg(po1.euler.rx).arg(po1.euler.ry).arg(po1.euler.rz)+
                         QString(u8"机械臂运行错误代码:[%1]; ").arg(Arm_Err)+ QString(u8"控制器错误代码:[%1]; ").arg(Sys_Err));
}

void MainWindow::on_pushButton_clicked()
{
    int ret = -1;

    ret = m_pApi->Service_Stop_Force_Position_Move(m_sockhand, 1);
    //初始位姿
    float joint[7] = {-61.449,36.747,64.543,0.37,79.383,-0.029,0};
    ret = m_pApi->Service_Movej_Cmd(m_sockhand, joint, 20, 0, 0,1);

    ret = m_pApi->Service_Start_Force_Position_Move(m_sockhand, 1);
    if(ret != 0)
    {
        ui->textEdit->append(QString( u8"开启透传力位混合补偿模式失败 :[%1]" ).arg(ret));
        return;
    }
    sleep_cp(1000);

    Pose nowpo;
    uint16_t Arm_Err,Sys_Err;
    ret = m_pApi->Service_Get_Current_Arm_State(m_sockhand, joint, &nowpo, &Arm_Err, &Sys_Err);

    //角度
//    for(int i=0;i<3;i++)
//    {
//        for (int j =0;j<500;j++)
//        {
//            joint[0]+=0.1;
//            ret = m_pApi->Service_Force_Position_Move_Joint (m_sockhand,joint,1,0,2,-2);
//            sleep_cp(20);

//        }
//        for (int k =0;k<500;k++)
//        {
//            joint[0]-=0.1;
//            ret = m_pApi->Service_Force_Position_Move_Joint (m_sockhand,joint,1,0,2,-2);
//            sleep_cp(20);
//        }
//    }

    //位姿
    for(int i=0;i<3;i++)
    {
        for (int j =0;j<50;j++)
        {
            nowpo.position.x+=0.001;
            ret = m_pApi->Service_Force_Position_Move_Pose(m_sockhand,nowpo,1,0,2,-5,true);
            sleep_cp(30);
        }
        for (int k =0;k<50;k++)
        {
            nowpo.position.x-=0.001;
            ret = m_pApi->Service_Force_Position_Move_Pose(m_sockhand,nowpo,1,0,2,-2,false);
            sleep_cp(30);
        }
    }

    ret = m_pApi->Service_Stop_Force_Position_Move(m_sockhand, 1);
    if(ret != 0)
    {
        ui->textEdit->append(QString(u8"停止透传力位混合补偿模式失败 :[%1]" ).arg(ret));
        return;
    }

    ui->textEdit->append(QString( u8"透传力位混合补偿模式结束 :[%1]" ).arg(ret));
}

void MainWindow::on_pushButton_2_clicked()
{
    int ret = -1;
    // 回零位
    float joint[6] = {0,0,0,0,0,0};
    ret = m_pApi->Service_Movej_Cmd(m_sockhand,joint,20,0,0,1);
    if(ret != 0)
    {
        ui->textEdit->append(QString("Movej_Cmd 1:[%1]").arg(ret));
        return;
    }
    float mJoint[7];
    Pose mPose;
    uint16_t mArmErr[7];
    uint16_t mSysErr[7];
    ret = m_pApi->Service_Get_Current_Arm_State(m_sockhand,mJoint, &mPose, mArmErr, mSysErr);
    ui->textEdit->append(QString("Pose: px:[%1] py:[%2] pz:[%3] rx[%4] ry:[%5] rz:[%6]")
                          .arg(mPose.position.x).arg(mPose.position.y).arg(mPose.position.z)
                          .arg(mPose.euler.rx).arg(mPose.euler.ry).arg(mPose.euler.rz));

    for(int i = 1;i<=100;i++)
    {
        mJoint[4]+=1;
        ret = m_pApi->Service_Movej_CANFD(m_sockhand,mJoint,false,0);
        sleep_cp(20);
    }
    ui->textEdit->append(QString(" Movej_CANFD: [%1]").arg(ret));

//     for(int i = 1;i<=300;i++)
//     {
//         mPose.pz+=0.01;
//         ret = m_pApi->Service_Movep_CANFD(m_sockhand,mPose);
//         sleep_cp(20);
//     }
//     ui->textEdit->append(QString("POSE: px:[%1] py:[%2] pz:[%3] rx[%4] ry:[%5] rz:[%6]")
//                           .arg(mPose.px).arg(mPose.py).arg(mPose.pz)
//                           .arg(mPose.rx).arg(mPose.ry).arg(mPose.rz));
}
